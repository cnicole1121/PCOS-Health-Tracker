package com.pcoshealthtracker.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcosHealthTrackerApplicationTests {

    @Test
    void contextLoads() {
        // Placeholder test to verify context loading
    }
}
