package com.pcoshealthtracker.app.controller;

import com.pcoshealthtracker.app.entity.Quote;
import com.pcoshealthtracker.app.repository.QuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;
import java.util.Random;

@RestController
@RequestMapping("/api/quote")
public class QuoteController {

    @Autowired
    private QuoteRepository quoteRepository;

    @GetMapping("/random")
    public Quote getRandomQuote() {
        long count = quoteRepository.count();
        if (count == 0) {
            throw new IllegalStateException("No quotes available.");
        }

        int randomIndex = new Random().nextInt((int) count); // Random index within range
        return quoteRepository.findAll(PageRequest.of(randomIndex, 1)).getContent().get(0); // Fetch random quote
    }

}
