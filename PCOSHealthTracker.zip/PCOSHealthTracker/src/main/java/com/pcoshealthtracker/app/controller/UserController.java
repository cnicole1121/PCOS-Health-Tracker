package com.pcoshealthtracker.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import com.pcoshealthtracker.app.service.UserService;
import com.pcoshealthtracker.app.dto.UserDTO;
import com.pcoshealthtracker.app.entity.User;
import com.pcoshealthtracker.app.repository.UserRepository;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @PostMapping("/check-availability")
    public ResponseEntity<?> checkAvailability(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String email = request.get("email");

        boolean isUsernameTaken = userRepository.existsByUsername(username);
        boolean isEmailTaken = userRepository.existsByEmail(email);

        if (isUsernameTaken || isEmailTaken) {
            String message = isUsernameTaken ? "Username already taken" : "Email already taken";
            return ResponseEntity.badRequest().body(Map.of("status", "error", "message", message));
        }

        return ResponseEntity.ok(Map.of("status", "success", "message", "Both username and email are available."));
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody UserDTO userDTO) {
        if (userRepository.existsByUsername(userDTO.getUsername())) {
            return ResponseEntity.badRequest().body(Map.of("status", "error", "message", "Username already taken"));
        }
        if (userRepository.existsByEmail(userDTO.getEmail())) {
            return ResponseEntity.badRequest().body(Map.of("status", "error", "message", "Email already taken"));
        }

        User newUser = new User();
        newUser.setFirstName(userDTO.getFirstName());
        newUser.setLastName(userDTO.getLastName());
        newUser.setUsername(userDTO.getUsername());
        newUser.setEmail(userDTO.getEmail());
        newUser.setPassword(passwordEncoder.encode(userDTO.getPassword())); // Hash the password

        userService.saveUser(newUser);

        return ResponseEntity.ok(Map.of("status", "success", "redirectUrl", "/login.html"));
    }
}
