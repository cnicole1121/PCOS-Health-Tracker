package com.pcoshealthtracker.app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf().disable() // Disable CSRF for simplicity, enable it in production
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                    "/", 
                    "/static/**",
                    "/index.html", 
                    "/registration.html",
                    "/login.html", 
                    "/mindfulness.html", 
                    "/api/register", 
                    "/api/check-availability", 
                    "/api/login",
                    "/api/quote/**",  // Allow access to quote API
                    "/css/**", 
                    "/js/**", 
                    "/images/**"
                ).permitAll() // Allow access without authentication
                .anyRequest().authenticated() // Require authentication for all other endpoints
            )
            .formLogin(form -> form
                .loginPage("/login.html") // Use the actual login page path
                .defaultSuccessUrl("/mindfulness.html", true) // Redirect to mindfulness after successful login
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login.html?logout") // Redirect to login page after logout
                .permitAll()
            );

        return http.build();
    }
}
