package com.pcoshealthtracker.app;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class PcosHealthTrackerApplication {

    public static void main(String[] args) {
        SpringApplication.run(PcosHealthTrackerApplication.class, args);
    }

    @Value("${my.test.property}")
    private String testProperty;

    @PostConstruct
    public void testProperty() {
        System.out.println("Test Property: " + testProperty);
    }
}
