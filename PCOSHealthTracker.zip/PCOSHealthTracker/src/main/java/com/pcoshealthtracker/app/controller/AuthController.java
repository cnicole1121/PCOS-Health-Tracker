package com.pcoshealthtracker.app.controller;

import com.pcoshealthtracker.app.entity.User;
import com.pcoshealthtracker.app.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:8080") // Adjust the origin if needed
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody Map<String, String> credentials) {
        String username = credentials.get("username");
        String password = credentials.get("password");

        if (username == null || password == null) {
            return ResponseEntity.badRequest().body(Map.of(
                "status", "error",
                "message", "Username and password are required"
            ));
        }

        // Log the incoming request
        System.out.println("Login attempt with username: " + username);

        User user = userRepository.findByUsername(username);
        if (user == null) {
            System.out.println("Login failed: Username not found");
            return ResponseEntity.badRequest().body(Map.of(
                "status", "error",
                "message", "Invalid username or password"
            ));
        }

        // Verify password
        boolean matches = passwordEncoder.matches(password, user.getPassword());
        System.out.println("Raw password: " + password);
        System.out.println("Hashed password: " + user.getPassword());
        System.out.println("Password matches: " + matches);

        if (!matches) {
            return ResponseEntity.badRequest().body(Map.of(
                "status", "error",
                "message", "Invalid username or password"
            ));
        }

        System.out.println("Login successful for user: " + username);
        return ResponseEntity.ok(Map.of(
            "status", "success",
            "redirectUrl", "/mindfulness.html",
            "message", "Login successful"
        ));
    }

    @PostMapping("/test-password")
    public ResponseEntity<?> testPassword(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String rawPassword = request.get("password");

        // Fetch the user from the database
        User user = userRepository.findByUsername(username);
        if (user == null) {
            return ResponseEntity.badRequest().body(Map.of(
                "status", "error",
                "message", "User not found"
            ));
        }

        // Check if the password matches
        boolean matches = passwordEncoder.matches(rawPassword, user.getPassword());
        System.out.println("Testing password for username: " + username);
        System.out.println("Raw password: " + rawPassword);
        System.out.println("Stored hashed password: " + user.getPassword());
        System.out.println("Password matches: " + matches);

        return ResponseEntity.ok(Map.of("matches", matches));
    }

    @GetMapping("/test-find-user")
    public ResponseEntity<?> testFindUser(@RequestParam String username) {
        System.out.println("Looking up user by username: " + username);
        User user = userRepository.findByUsernameIgnoreCase(username);
        if (user == null) {
            System.out.println("User not found in database");
            return ResponseEntity.badRequest().body(Map.of(
                "status", "error",
                "message", "User not found"
            ));
        }
        System.out.println("User found: " + user);
        return ResponseEntity.ok(Map.of(
            "status", "success",
            "user", user
        ));
    }

    @PostMapping("/test-hash-matching")
    public ResponseEntity<?> testHashMatching(@RequestBody Map<String, String> request) {
        String rawPassword = request.get("rawPassword");
        String hashedPassword = request.get("hashedPassword");

        boolean matches = passwordEncoder.matches(rawPassword, hashedPassword);
        System.out.println("Raw password: " + rawPassword);
        System.out.println("Hashed password: " + hashedPassword);
        System.out.println("Password matches: " + matches);

        return ResponseEntity.ok(Map.of("matches", matches));
    }
}
