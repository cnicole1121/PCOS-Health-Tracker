package com.pcoshealthtracker.app.service;

import com.pcoshealthtracker.app.entity.User;
import com.pcoshealthtracker.app.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // Constructor-based dependency injection
    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public void saveUser(User user) {
        System.out.println("Password before hashing: " + user.getPassword());
        String hashedPassword = passwordEncoder.encode(user.getPassword());
        System.out.println("Hashed password: " + hashedPassword);
        user.setPassword(hashedPassword);
        userRepository.save(user);
    }

    public boolean isEmailTaken(String email) {
        return userRepository.existsByEmail(email);
    }

    public boolean isUsernameTaken(String username) {
        return userRepository.existsByUsername(username);
    }
}
