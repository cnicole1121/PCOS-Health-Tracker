let autoRefreshInterval;

async function fetchQuote() {
    try {
        const response = await fetch("http://localhost:8080/api/quote/random");
        const data = await response.json();

        if (data.text) {
            document.getElementById("quote-text").innerText = `"${data.text}"`;
            document.getElementById("quote-source").innerText = `- ${data.source}`;
        } else {
            document.getElementById("quote-text").innerText = "No quote available.";
            document.getElementById("quote-source").innerText = "";
        }
    } catch (error) {
        console.error("Error fetching quote:", error);
        document.getElementById("quote-text").innerText = "Error loading quote.";
        document.getElementById("quote-source").innerText = "";
    }
}


// Initialize event listeners and fetch the first quote
document.addEventListener("DOMContentLoaded", () => {
    fetchQuote(); // Fetch a quote on page load
    document.getElementById("refresh-quote").addEventListener("click", fetchQuote); // Set up manual refresh
    setupAutoRefresh(); // Set up auto-refresh toggle
});
