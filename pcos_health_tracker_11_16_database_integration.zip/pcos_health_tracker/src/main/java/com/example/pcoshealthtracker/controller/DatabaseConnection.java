package com.example.pcoshealthtracker.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // Database URL, Username, and Password
    private static final String URL = "jdbc:mysql://localhost:3306/pcos_health_tracker";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "563324";

    // Method to establish and return a database connection
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
