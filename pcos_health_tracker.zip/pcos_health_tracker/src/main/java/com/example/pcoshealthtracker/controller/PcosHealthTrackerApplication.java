
package com.example.pcoshealthtracker.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcosHealthTrackerApplication {

    public static void main(String[] args) {
        SpringApplication.run(PcosHealthTrackerApplication.class, args);
    }
}
